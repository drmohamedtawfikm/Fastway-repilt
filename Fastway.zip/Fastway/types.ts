
export interface Restaurant {
  id: string;
  name: string;
  category: string;
  deliveryTime: string;
  cashbackPercentage: number;
  imageUrl: string;
}

export interface Dish {
  id: string;
  name: string;
  price: number;
  description: string;
}

export interface OrderDetails {
  restaurantId: string;
  dishId: string;
  name: string;
  phone: string;
  address: string;
  paymentMethod: 'cash' | 'wallet';
  totalPrice: number;
  cashbackAmount: number;
}
