
import React, { useState } from 'react';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import QuickOrder from './components/QuickOrder';
import Stats from './components/Stats';
import Trust from './components/Trust';
import Footer from './components/Footer';
import RestaurantJoinModal from './components/RestaurantJoinModal';
import AdminPanel from './components/AdminPanel';

const App: React.FC = () => {
  const [isRestaurantJoinOpen, setIsRestaurantJoinOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  const openRestaurantJoin = () => setIsRestaurantJoinOpen(true);
  const closeRestaurantJoin = () => setIsRestaurantJoinOpen(false);

  return (
    <div className="min-h-screen grid-bg text-black overflow-x-hidden pb-24" dir="rtl">
      {/* Header */}
      <header className="fixed top-4 left-4 right-4 z-[100] max-w-5xl mx-auto">
        <div className="bg-white/80 backdrop-blur-xl border border-gray-100 rounded-[24px] px-6 py-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-4">
            <button 
              onClick={openRestaurantJoin}
              className="bg-easy-green text-white px-6 py-2.5 rounded-full font-bold text-sm shadow-lg shadow-green-200"
            >
              انضم كمطعم مجاناً
            </button>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-2xl font-black tracking-tighter text-black">Fastway</span>
            <div className="w-10 h-10 bg-easy-green rounded-xl flex items-center justify-center transform rotate-12">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M2.01 21L23 12L2.01 3L2 10l15 2l-15 2z" />
              </svg>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-32">
        <Hero onJoinRestaurant={openRestaurantJoin} />
        <div id="how-it-works"><HowItWorks /></div>
        <QuickOrder />
        <Stats />
        <Trust />
      </main>

      <Footer 
        onJoinRestaurant={openRestaurantJoin} 
        onAdminLogin={() => setIsAdminPanelOpen(true)}
      />
      
      <RestaurantJoinModal isOpen={isRestaurantJoinOpen} onClose={closeRestaurantJoin} />
      <AdminPanel isOpen={isAdminPanelOpen} onClose={() => setIsAdminPanelOpen(false)} />

      {/* Navigation Pill */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[90]">
        <a href="#quick-order" className="bg-white/90 backdrop-blur-xl border border-gray-100 rounded-full px-8 py-3 flex items-center gap-3 shadow-2xl hover:scale-105 transition-all">
          <div className="w-6 h-6 bg-easy-green/10 rounded-full flex items-center justify-center">
            <div className="w-2 h-2 bg-easy-green rounded-full"></div>
          </div>
          <span className="font-bold text-sm text-gray-700">اطلب وجبتك الآن</span>
        </a>
      </div>
    </div>
  );
};

export default App;
