
export const DEFAULT_DATA = {
  restaurants: [
    'بازوكا - Bazooka',
    'بـ لبن - B.Laban',
    'قصر الكبابجي',
    'حضرموت عنتر',
    'كشري التحرير',
    'ابن الشام',
    'بافالو برجر',
    'البرنس - El Prens',
    'زووبا - Zooba',
    'أبو مازن السوري',
    'ويليز برجر',
    'سلطان الفطائر'
  ],
  cities: [
    { id: 'cairo', name: 'القاهرة' },
    { id: 'giza', name: 'الجيزة' },
    { id: 'alex', name: 'الإسكندرية' },
    { id: 'mansoura', name: 'المنصورة' },
    { id: 'طنطا', name: 'طنطا' },
    { id: 'الزقازيق', name: 'الزقازيق' }
  ]
};
