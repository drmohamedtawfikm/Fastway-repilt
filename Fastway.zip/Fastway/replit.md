# Fastway Egypt - Cashback Food Ordering

## Overview
Fastway is a food ordering landing page for an Egyptian cashback food delivery service. Users can browse restaurants, place orders, and earn cashback. The site is in Arabic (RTL layout).

## Project Architecture
- **Framework**: React 19 + TypeScript
- **Build Tool**: Vite 6
- **Styling**: Tailwind CSS (via CDN), inline styles with Cairo font
- **Language**: Arabic (RTL)

## Project Structure
```
/
├── App.tsx              # Main app component with header, modals
├── index.tsx            # React root entry point
├── index.html           # HTML template with Tailwind CDN
├── vite.config.ts       # Vite config (port 5000, all hosts allowed)
├── tsconfig.json        # TypeScript config
├── constants.ts         # App constants
├── dailyData.ts         # Daily data
├── types.ts             # TypeScript types
├── components/
│   ├── AdminPanel.tsx
│   ├── Footer.tsx
│   ├── Hero.tsx
│   ├── HowItWorks.tsx
│   ├── Navbar.tsx
│   ├── OrderModal.tsx
│   ├── QuickOrder.tsx
│   ├── RestaurantCard.tsx
│   ├── RestaurantJoinModal.tsx
│   ├── RestaurantList.tsx
│   ├── Stats.tsx
│   └── Trust.tsx
```

## Development
- Dev server: `npm run dev` (runs on port 5000)
- Build: `npm run build` (outputs to `dist/`)
- Deployment: Static site deployment from `dist/`

## Recent Changes
- Removed unused `@google/genai` dependency
- Removed import map from index.html (using Vite bundling instead)
- Updated Vite config: port 5000, allowedHosts enabled for Replit proxy
