
import { Restaurant, Dish } from './types';

export const RESTAURANTS: Restaurant[] = [
  {
    id: '1',
    name: 'برنس البيتزا',
    category: 'إيطالي / بيتزا',
    deliveryTime: '٣٠ - ٤٥ دقيقة',
    cashbackPercentage: 15,
    imageUrl: 'https://picsum.photos/seed/pizza1/400/300',
  },
  {
    id: '2',
    name: 'كشري الزعيم',
    category: 'مصري / شعبي',
    deliveryTime: '٢٠ - ٣٥ دقيقة',
    cashbackPercentage: 10,
    imageUrl: 'https://picsum.photos/seed/koshary1/400/300',
  },
  {
    id: '3',
    name: 'برجر فاكتوري',
    category: 'سندوتشات / برجر',
    deliveryTime: '٤٠ - ٥٠ دقيقة',
    cashbackPercentage: 8,
    imageUrl: 'https://picsum.photos/seed/burger1/400/300',
  },
  {
    id: '4',
    name: 'حلواني الصعيدي',
    category: 'حلويات / شرقي',
    deliveryTime: '٢٥ - ٤٠ دقيقة',
    cashbackPercentage: 12,
    imageUrl: 'https://picsum.photos/seed/sweet1/400/300',
  },
];

export const DISHES: Record<string, Dish[]> = {
  '1': [
    { id: 'd1', name: 'بيتزا مارجريتا جامبو', price: 120, description: 'صلصة طماطم، موتزاريلا، ريحان' },
    { id: 'd2', name: 'بيتزا تشيكن رانش', price: 180, description: 'دجاج مشوي، رانش صوص، موتزاريلا' },
  ],
  '2': [
    { id: 'd3', name: 'علبة الزعيم لوكس', price: 45, description: 'كشري بجميع الإضافات + صلصة زيادة' },
    { id: 'd4', name: 'طاجن مكرونة باللحمة', price: 60, description: 'مكرونة فرن باللحمة المفرومة والصلصة' },
  ],
  '3': [
    { id: 'd5', name: 'دبل تشيز برجر', price: 150, description: 'قطعتين لحم، جبنة شيدر، صوص بيج فاكتوري' },
    { id: 'd6', name: 'ميلت برجر بالبيض', price: 130, description: 'برجر مشوي مع بيض عيون وجبنة' },
  ],
  '4': [
    { id: 'd7', name: 'طبق بسبوسة بالمكسرات', price: 90, description: 'كيلو بسبوسة بالسمن البلدي' },
    { id: 'd8', name: 'علبة مشكل لوكس', price: 200, description: 'تشكيلة حلويات شرقية فاخرة' },
  ],
};
